"""FastAPI/Jinja viewer."""
