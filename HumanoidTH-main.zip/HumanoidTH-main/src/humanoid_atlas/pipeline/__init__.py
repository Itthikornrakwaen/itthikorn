"""Atlas processing pipeline."""
